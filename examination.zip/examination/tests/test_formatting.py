"""
tester i pris (exempel):
int 123 ger float 123.00
123.4 output: 123.40
123.456 output: 123.46
None = "-" 

tester procent:
1.234 ger output: 1.23 %
-0.8 ger output: -0.80%
0 ger 0.00 %
None = "-"

stora och små tal ska hanteras utan kracsh
inga blanksteg eller feltecken
"""