"""
BörsLexikon – hämtar riktig aktiedata från Polygon.io
INGEN MOCK – bara riktig API med offentlig demokey
Fungerar för alla tickers (TSLA, AAPL, MSFT, osv) och alla datum
"""

import datetime
from polygon import RESTClient  # pip install polygon-api-client

# OFFENTLIG DEMO-NYCKEL – funkar för alla, ingen registrering!
API_KEY = "oF9Vm4pGKHFZzCMt6EKt1KKruaLjokaY"

# Lokala företagsnamn – fallback om API inte ger namn
company_names = {
    "AAPL": "Apple Inc.",
    "TSLA": "Tesla Motors",
    "NVDA": "Nvidia Corp",
    "MSFT": "Microsoft Corp",
    "AMZN": "Amazon",
    "GOOG": "Alphabet Inc (Google)",
    "PLTR": "Palantir Tech",
    "RCAT": "Red Cat Holdings",
    "ONDS": "Ondas Holdings"
}

"""räknar ut procentförändring från open till close"""
def compute_pct_change(open_price, close_price):
    if not open_price or open_price == 0 or not close_price:
        return None
    return round(((close_price - open_price) / open_price) * 100, 2)

"""hämtar företagsnamn eller använder ticker"""
def lookup_name(ticker):
    return company_names.get(ticker, ticker)

"""hämtar OHLC-data från Polygon API"""
def fetch_from_polygon(ticker, date):
    try:
        client = RESTClient(API_KEY)
        aggs = client.get_aggs(
            ticker=ticker.upper(),
            multiplier=1,
            timespan="day",
            from_=date,
            to=date,
            adjusted=True,
            limit=1
        )
        if not aggs:
            return None
        post = aggs[0]
        return {
            "open": post.open,
            "high": post.high,
            "low": post.low,
            "close": post.close
        }
    except Exception as e:
        print(f"API-fel ({ticker}): {e}")
        return None

"""hämta pris för ett datum – bara från API"""
def fetch_quote_for_date(ticker, date):
    return fetch_from_polygon(ticker, date)

"""huvudfunktion – returnerar tabell + varningar"""
def fetch_prices(items, date):
    rows = []
    warnings = []

    # konvertera datum om det är sträng
    if isinstance(date, str):
        try:
            parsed_date = datetime.date.fromisoformat(date)
        except ValueError:
            warnings.append(f"Ogiltigt datum: {date}")
            return {"data": [], "warnings": warnings}
    else:
        parsed_date = date

    for ticker in items:
        quote = fetch_quote_for_date(ticker, parsed_date)
        if not quote:
            warnings.append(f"Ingen data för {ticker} på {parsed_date}")
            continue

        name = lookup_name(ticker)
        o, h, l, c = quote["open"], quote["high"], quote["low"], quote["close"]

        if None in (o, h, l, c):
            warnings.append(f"Ofullständig data för {ticker}")
            continue

        pct = compute_pct_change(o, c)
        rows.append({
            "ticker": ticker,
            "name": name,
            "open": round(o, 2),
            "high": round(h, 2),
            "low": round(l, 2),
            "close": round(c, 2),
            "pct_change": pct
        })

    return {"data": rows, "warnings": warnings}